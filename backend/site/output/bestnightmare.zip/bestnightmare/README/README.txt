[========================================]
[========================================]
|  Song:                     Author:     |
|  Your Best Nightmare       Toby Fox    |
[========================================]
|  Charted and Decorated by:             |
|  Name: Toatd                           |
|  Discord Tag: toatd                    |
[========================================]
[========================================]

Hi! Thanks for playing my level!

This level took about 2 and a half weeks to make if you include time spent
in other software such as Gimp and Aesprite.

This is only my second chart so forgive me if the difficulty isn't the best!

Also, feel free to use any of the assets in this level  if you want to make
your own, or even modify my level.

Thanks,
Toatd